# MarkerBox (Fabric, Minecraft 1.21.11, client-seitig)

## Bauen
Voraussetzung: JDK 21.
Gradle-Wrapper ergänzen (z. B. aus dem Fabric-Template https://fabricmc.net/develop/template/ kopieren
oder `gradle wrapper --gradle-version latest`), dann:

    ./gradlew build

Die fertige Mod liegt in `build/libs/markerbox-1.0.0+1.21.11.jar`
(zusammen mit Fabric API in den mods-Ordner legen; nur auf dem Client nötig).

## Bedienung (alle Tasten unter Steuerung -> MarkerBox änderbar)
- M          Item unter dem Mauszeiger markieren / Markierung entfernen (ohne Menü: Item in der Haupthand)
- Shift + M  nur 1 Stück statt des ganzen Stacks markieren
- G          /give-Befehl in die Zwischenablage kopieren
- Shift + G  Befehl direkt ausführen (kein 256-Zeichen-Limit)
- K          alle Markierungen löschen
