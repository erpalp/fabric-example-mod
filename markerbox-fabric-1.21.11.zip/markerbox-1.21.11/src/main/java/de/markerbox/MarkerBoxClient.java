package de.markerbox;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class MarkerBoxClient implements ClientModInitializer {
    public static KeyBinding MARK_KEY;
    public static KeyBinding GENERATE_KEY;
    public static KeyBinding CLEAR_KEY;

    @Override
    public void onInitializeClient() {
        // Ab 1.21.9 sind Kategorien Objekte; Übersetzungsschlüssel: key.category.markerbox.main
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("markerbox", "main"));

        MARK_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.markerbox.mark", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, category));
        GENERATE_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.markerbox.generate", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, category));
        CLEAR_KEY = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.markerbox.clear", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, category));

        // Tasten im normalen Spiel (ohne offenes Menü): markiert das Item in der Haupthand
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.currentScreen != null) return;
            while (MARK_KEY.wasPressed()) {
                MarkerManager.toggle(client, client.player.getMainHandStack(), MarkerManager.isShiftDown(client));
            }
            while (GENERATE_KEY.wasPressed()) {
                MarkerManager.generate(client, MarkerManager.isShiftDown(client));
            }
            while (CLEAR_KEY.wasPressed()) {
                MarkerManager.clear(client);
            }
        });

        // Tooltip-Hinweis bei markierten Items
        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            if (MarkerManager.isMarked(stack)) {
                lines.add(Text.translatable("tooltip.markerbox.marked").formatted(Formatting.GREEN));
            }
        });
    }
}
