package de.markerbox.mixin;

import de.markerbox.MarkerBoxClient;
import de.markerbox.MarkerManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.screen.slot.Slot;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {

    @Shadow
    protected Slot focusedSlot;
    @Shadow
    protected int x;
    @Shadow
    protected int y;

    /** Tasten in Inventaren/Kisten: markiert das Item unter dem Mauszeiger. */
    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void markerbox$keyPressed(KeyInput input, CallbackInfoReturnable<Boolean> cir) {
        Screen self = (Screen) (Object) this;
        // Nicht eingreifen, wenn gerade in ein Textfeld getippt wird (Suche, Amboss-Name ...)
        if (self.getFocused() instanceof TextFieldWidget) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        boolean shift = (input.modifiers() & GLFW.GLFW_MOD_SHIFT) != 0;

        if (MarkerBoxClient.MARK_KEY.matchesKey(input)) {
            if (focusedSlot != null && focusedSlot.hasStack()) {
                MarkerManager.toggle(mc, focusedSlot.getStack(), shift);
                cir.setReturnValue(true);
            }
        } else if (MarkerBoxClient.GENERATE_KEY.matchesKey(input)) {
            MarkerManager.generate(mc, shift);
            cir.setReturnValue(true);
        } else if (MarkerBoxClient.CLEAR_KEY.matchesKey(input)) {
            MarkerManager.clear(mc);
            cir.setReturnValue(true);
        }
    }

    /** Grüner Rahmen um markierte Slots (am Ende von render, unabhängig von drawSlot-Signaturen). */
    @Inject(method = "render", at = @At("TAIL"))
    private void markerbox$render(DrawContext context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        HandledScreen<?> self = (HandledScreen<?>) (Object) this;
        for (Slot slot : self.getScreenHandler().slots) {
            if (!slot.isEnabled() || !slot.hasStack() || !MarkerManager.isMarked(slot.getStack())) continue;
            int x1 = this.x + slot.x - 1;
            int y1 = this.y + slot.y - 1;
            int x2 = x1 + 18;
            int y2 = y1 + 18;
            int color = 0xFF55FF55;
            context.fill(x1, y1, x2, y1 + 1, color);     // oben
            context.fill(x1, y2 - 1, x2, y2, color);     // unten
            context.fill(x1, y1 + 1, x1 + 1, y2 - 1, color); // links
            context.fill(x2 - 1, y1 + 1, x2, y2 - 1, color); // rechts
        }
    }
}
