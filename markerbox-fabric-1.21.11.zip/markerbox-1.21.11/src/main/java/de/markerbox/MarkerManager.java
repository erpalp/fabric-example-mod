package de.markerbox;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtOps;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public final class MarkerManager {
    /** Eine Shulker Box hat 27 Slots. */
    public static final int MAX_ITEMS = 27;

    private static final List<ItemStack> MARKED = new ArrayList<>();

    private MarkerManager() {}

    public static boolean isShiftDown(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();
        return GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
    }

    private static int indexOf(ItemStack stack) {
        for (int i = 0; i < MARKED.size(); i++) {
            if (ItemStack.areItemsAndComponentsEqual(MARKED.get(i), stack)) return i;
        }
        return -1;
    }

    public static boolean isMarked(ItemStack stack) {
        return !stack.isEmpty() && indexOf(stack) >= 0;
    }

    /** Markiert das Item oder entfernt die Markierung. singleItem = nur 1 Stück statt des ganzen Stacks. */
    public static void toggle(MinecraftClient mc, ItemStack stack, boolean singleItem) {
        if (mc.player == null) return;
        if (stack.isEmpty()) {
            mc.player.sendMessage(Text.literal("§7Kein Item zum Markieren."), true);
            return;
        }
        int idx = indexOf(stack);
        if (idx >= 0) {
            MARKED.remove(idx);
            mc.player.sendMessage(Text.literal("§eMarkierung entfernt §7(" + MARKED.size() + "/" + MAX_ITEMS + ")"), true);
            return;
        }
        if (MARKED.size() >= MAX_ITEMS) {
            mc.player.sendMessage(Text.literal("§cShulker Box ist voll (" + MAX_ITEMS + " Slots)."), true);
            return;
        }
        ItemStack copy = stack.copy();
        copy.setCount(singleItem ? 1 : stack.getCount());
        MARKED.add(copy);
        mc.player.sendMessage(Text.literal("§aMarkiert: §f" + copy.getCount() + "x " + copy.getName().getString()
                + " §7(" + MARKED.size() + "/" + MAX_ITEMS + ")"), true);
    }

    public static void clear(MinecraftClient mc) {
        MARKED.clear();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal("§eAlle Markierungen gelöscht."), true);
        }
    }

    /** Baut den Befehl (ohne führenden Slash). */
    private static String buildCommand(MinecraftClient mc) {
        try {
            var ops = mc.world.getRegistryManager().getOps(NbtOps.INSTANCE);
            NbtList container = new NbtList();
            for (int i = 0; i < MARKED.size(); i++) {
                NbtElement itemTag = ItemStack.CODEC.encodeStart(ops, MARKED.get(i)).getOrThrow();
                NbtCompound entry = new NbtCompound();
                entry.putInt("slot", i);
                entry.put("item", itemTag);
                container.add(entry);
            }
            return "give @s minecraft:shulker_box[container=" + container + "]";
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void generate(MinecraftClient mc, boolean sendDirectly) {
        if (mc.player == null || mc.world == null) return;
        if (MARKED.isEmpty()) {
            mc.player.sendMessage(Text.literal("§cKeine Items markiert."), true);
            return;
        }
        String command = buildCommand(mc);
        if (command == null) {
            mc.player.sendMessage(Text.literal("§cBefehl konnte nicht erzeugt werden (siehe Log)."), false);
            return;
        }

        if (sendDirectly) {
            mc.player.networkHandler.sendChatCommand(command);
            mc.player.sendMessage(Text.literal("§aBefehl ausgeführt §7(" + MARKED.size() + " Items)."), true);
            return;
        }

        mc.keyboard.setClipboard("/" + command);
        String msg = "§aGive-Befehl in die Zwischenablage kopiert §7(" + MARKED.size() + " Items, "
                + (command.length() + 1) + " Zeichen).";
        if (command.length() + 1 > 256) {
            msg += " §eHinweis: Länger als 256 Zeichen – nutze Shift+Taste zum direkten Ausführen oder einen Befehlsblock.";
        }
        mc.player.sendMessage(Text.literal(msg), false);
    }
}
